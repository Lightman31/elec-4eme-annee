/* 
 * File:   main.h
 * Author: Adrian Chazottes
 *
 * Created on 18 novembre 2016, 10:00
 */

#ifndef MAIN_H
#define	MAIN_H


#include <stdio.h>
#include <stdlib.h>
#include "glcd.h"
#include "init.h"

#endif	/* MAIN_H */

