#include "Talkthrough.h"

//--------------------------------------------------------------------------//
// Function:	Process_Data()												//
//																			//
// Description: This function is called from inside the SPORT0 ISR every 	//
//				time a complete audio frame has been received. The new 		//
//				input samples can be found in the variables iChannel0LeftIn,//
//				iChannel0RightIn, iChannel1LeftIn and iChannel1RightIn 		//
//				respectively. The processed	data should be stored in 		//
//				iChannel0LeftOut, iChannel0RightOut, iChannel1LeftOut,		//
//				iChannel1RightOut, iChannel2LeftOut and	iChannel2RightOut	//
//				respectively.												//
//--------------------------------------------------------------------------//
void Process_Data(void)
{

	/*iChannel0LeftOut = iChannel0LeftIn & 0x00FFFF00;
	iChannel0RightOut = iChannel0RightIn & 0x00FFFF00;
	iChannel0LeftOut = iChannel0LeftIn ;
	iChannel0RightOut = iChannel0RightIn;*/
	iChannel0LeftOut = iChannel0LeftIn & 0xFFFFF000;
	iChannel0RightOut = iChannel0RightIn & 0xFFFFF000;


	

	
	iChannel1LeftOut = iChannel1LeftIn;
	iChannel1RightOut = iChannel1RightIn;

	
}
